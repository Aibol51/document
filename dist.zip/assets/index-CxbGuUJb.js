import{_ as e,n as c,p as n}from"./index-PrIw6d4_.js";const t={};function r(o,a){return c(),n("div",null," contract ")}const _=e(t,[["render",r]]);export{_ as default};
